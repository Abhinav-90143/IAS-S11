import socket
import threading
import secrets
import json

HOST = "127.0.0.1"
PORT = 5008

P = 23
G = 5

PRIVATE_KEY = secrets.randbelow(P - 2) + 2


def generate_public_key():
    return pow(G, PRIVATE_KEY, P)


def generate_shared_secret(client_public_key):
    return pow(client_public_key, PRIVATE_KEY, P)


def xor_encrypt(text, secret):
    data = text.encode()
    key = secret.to_bytes(2, "big")

    encrypted = bytes(
        data[i] ^ key[i % len(key)]
        for i in range(len(data))
    )

    return encrypted.hex()


def xor_decrypt(ciphertext, secret):
    data = bytes.fromhex(ciphertext)
    key = secret.to_bytes(2, "big")

    decrypted = bytes(
        data[i] ^ key[i % len(key)]
        for i in range(len(data))
    )

    return decrypted.decode()


def receive_messages(conn, shared_secret):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = xor_decrypt(data, shared_secret)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 55)
print("              DIFFIE-HELLMAN SERVER")
print("=" * 55)

print()
print("Algorithm : Diffie-Hellman Key Exchange")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nPublic Parameters:")
print("P (Prime)       :", P)
print("G (Generator)   :", G)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

server_public_key = generate_public_key()

print("\nServer Key Information:")
print("Private Key (a) :", PRIVATE_KEY)
print("Public Key (A)  :", server_public_key)

handshake = {
    "P": P,
    "G": G,
    "A": server_public_key
}

conn.send((json.dumps(handshake) + "\n").encode())

client_data = b""

while b"\n" not in client_data:
    client_data += conn.recv(1024)

client_message = client_data.decode().strip()
client_public_key = json.loads(client_message)["B"]

shared_secret = generate_shared_secret(client_public_key)

print("\nClient Public Key (B):", client_public_key)
print("Shared Secret (S)    :", shared_secret)

print("\nDiffie-Hellman Equation:")
print("S = B^a mod P")

print("\nKey exchange completed successfully.")
print("Shared secret established.")

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn, shared_secret),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter server message: ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        ciphertext = xor_encrypt(message, shared_secret)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending encrypted data to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break


conn.close()
server.close()

print("\nServer closed.")