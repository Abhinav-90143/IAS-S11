import socket
import threading
import json

HOST = "127.0.0.1"
PORT = 5008


def generate_public_key(private_key, g, p):
    return pow(g, private_key, p)


def generate_shared_secret(server_public_key, private_key, p):
    return pow(server_public_key, private_key, p)


def xor_encrypt(text, secret):
    data = text.encode()
    key = secret.to_bytes(2, "big")

    encrypted = bytes(
        data[i] ^ key[i % len(key)]
        for i in range(len(data))
    )

    return encrypted.hex()


def xor_decrypt(ciphertext, secret):
    data = bytes.fromhex(ciphertext)
    key = secret.to_bytes(2, "big")

    decrypted = bytes(
        data[i] ^ key[i % len(key)]
        for i in range(len(data))
    )

    return decrypted.decode()


def receive_messages(sock, shared_secret):
    while True:
        try:
            data = sock.recv(4096).decode()

            if not data:
                print("\nConnection closed by server.")
                break

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = xor_decrypt(data, shared_secret)

            print("\n" + "=" * 55)
            print("SERVER -> CLIENT")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 55)
print("              DIFFIE-HELLMAN CLIENT")
print("=" * 55)

print()
print("Algorithm : Diffie-Hellman Key Exchange")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server.")

# Receive server's Diffie-Hellman parameters and public key
server_data = b""

while b"\n" not in server_data:
    server_data += client.recv(1024)

handshake = json.loads(server_data.decode().strip())

P = handshake["P"]
G = handshake["G"]
server_public_key = handshake["A"]

print("\nPublic Parameters:")
print("P (Prime)       :", P)
print("G (Generator)   :", G)

# Generate client's private and public keys
private_key = 7
client_public_key = generate_public_key(private_key, G, P)

print("\nClient Key Information:")
print("Private Key (b) :", private_key)
print("Public Key (B)  :", client_public_key)

# Send client's public key to server
client.send(
    (json.dumps({"B": client_public_key}) + "\n").encode()
)

# Generate shared secret
shared_secret = generate_shared_secret(
    server_public_key,
    private_key,
    P
)

print("\nServer Public Key (A):", server_public_key)
print("Shared Secret (S)    :", shared_secret)

print("\nDiffie-Hellman Equation:")
print("S = A^b mod P")

print("\nKey exchange completed successfully.")
print("Shared secret established.")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(client, shared_secret),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            client.send("exit".encode())
            print("Client ended the communication.")
            break

        ciphertext = xor_encrypt(message, shared_secret)

        print("\n" + "=" * 55)
        print("CLIENT -> SERVER")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending encrypted data to server...")
        print("=" * 55)

        client.send(ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break


client.close()

print("\nClient closed.")