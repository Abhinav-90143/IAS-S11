import socket
import threading

HOST = "127.0.0.1"
PORT = 5005

KEY = "1010000010"

P10 = [3, 5, 2, 7, 4, 10, 1, 9, 8, 6]
P8 = [6, 3, 7, 4, 8, 5, 10, 9]

IP = [2, 6, 3, 1, 4, 8, 5, 7]
IP_INV = [4, 1, 3, 5, 7, 2, 8, 6]

EP = [4, 1, 2, 3, 2, 3, 4, 1]
P4 = [2, 4, 3, 1]

S0 = [
    [1, 0, 3, 2],
    [3, 2, 1, 0],
    [0, 2, 1, 3],
    [3, 1, 3, 2]
]

S1 = [
    [0, 1, 2, 3],
    [2, 0, 1, 3],
    [3, 0, 1, 0],
    [2, 1, 0, 3]
]


def permute(bits, table):
    return "".join(bits[i - 1] for i in table)


def left_shift(bits, count):
    return bits[count:] + bits[:count]


def generate_keys():
    p10 = permute(KEY, P10)

    left = p10[:5]
    right = p10[5:]

    left = left_shift(left, 1)
    right = left_shift(right, 1)

    k1 = permute(left + right, P8)

    left = left_shift(left, 2)
    right = left_shift(right, 2)

    k2 = permute(left + right, P8)

    return k1, k2


def xor_bits(a, b):
    return "".join("1" if x != y else "0" for x, y in zip(a, b))


def sbox_lookup(bits, sbox):
    row = int(bits[0] + bits[3], 2)
    column = int(bits[1] + bits[2], 2)

    value = sbox[row][column]

    return format(value, "02b")


def fk(bits, key):
    left = bits[:4]
    right = bits[4:]

    expanded = permute(right, EP)
    xored = xor_bits(expanded, key)

    left_sbox = sbox_lookup(xored[:4], S0)
    right_sbox = sbox_lookup(xored[4:], S1)

    p4 = permute(left_sbox + right_sbox, P4)

    new_left = xor_bits(left, p4)

    return new_left + right


def switch_halves(bits):
    return bits[4:] + bits[:4]


def sdes_encrypt(bits):
    k1, k2 = generate_keys()

    bits = permute(bits, IP)
    bits = fk(bits, k1)
    bits = switch_halves(bits)
    bits = fk(bits, k2)
    bits = permute(bits, IP_INV)

    return bits


def sdes_decrypt(bits):
    k1, k2 = generate_keys()

    bits = permute(bits, IP)
    bits = fk(bits, k2)
    bits = switch_halves(bits)
    bits = fk(bits, k1)
    bits = permute(bits, IP_INV)

    return bits


def receive_messages(conn):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = sdes_decrypt(data)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                 S-DES SERVER")
print("=" * 55)

print()
print("Algorithm : Simplified DES (S-DES)")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)
print("Key       :", KEY)

k1, k2 = generate_keys()

print("\nGenerated Subkeys:")
print("K1        :", k1)
print("K2        :", k2)

print("\nBlock Size: 8 bits")
print("Key Size  : 10 bits")

print("\nFeistel Operations:")
print("L(i+1) = R(i)")
print("R(i+1) = L(i) XOR F(R(i), Ki)")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

conn.send(KEY.encode())

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn,),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter server message (8-bit binary): ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        if len(message) != 8 or any(bit not in "01" for bit in message):
            print("Please enter exactly 8 binary bits.")
            continue

        ciphertext = sdes_encrypt(message)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break


conn.close()
server.close()

print("\nServer closed.")