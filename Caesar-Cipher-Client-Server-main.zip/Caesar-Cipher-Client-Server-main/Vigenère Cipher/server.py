import socket
import threading

HOST = "127.0.0.1"
PORT = 5004

KEY = "KEY"


def vigenere_encrypt(text):
    text = "".join(char.upper() for char in text if char.isalpha())

    result = ""
    key_index = 0

    for char in text:
        p = ord(char) - ord('A')
        k = ord(KEY[key_index % len(KEY)]) - ord('A')
        c = (p + k) % 26

        result += chr(c + ord('A'))
        key_index += 1

    return result


def vigenere_decrypt(text):
    result = ""
    key_index = 0

    for char in text:
        c = ord(char) - ord('A')
        k = ord(KEY[key_index % len(KEY)]) - ord('A')
        p = (c - k) % 26

        result += chr(p + ord('A'))
        key_index += 1

    return result


def receive_messages(conn):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = vigenere_decrypt(data)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("              VIGENERE CIPHER SERVER")
print("=" * 55)

print()
print("Algorithm : Vigenère Cipher")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)
print("Key       :", KEY)

print("\nKey Information:")
print("C = (P + K) mod 26")
print("P = (C - K) mod 26")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

conn.send(KEY.encode())

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn,),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter server message: ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        ciphertext = vigenere_encrypt(message)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break


conn.close()
server.close()

print("\nServer closed.")