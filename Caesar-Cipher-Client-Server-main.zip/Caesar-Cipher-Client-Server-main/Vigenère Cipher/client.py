import socket
import threading

HOST = "127.0.0.1"
PORT = 5004

KEY = "KEY"


def vigenere_encrypt(text):
    text = "".join(char.upper() for char in text if char.isalpha())

    result = ""
    key_index = 0

    for char in text:
        p = ord(char) - ord('A')
        k = ord(KEY[key_index % len(KEY)]) - ord('A')
        c = (p + k) % 26

        result += chr(c + ord('A'))
        key_index += 1

    return result


def vigenere_decrypt(text):
    result = ""
    key_index = 0

    for char in text:
        c = ord(char) - ord('A')
        k = ord(KEY[key_index % len(KEY)]) - ord('A')
        p = (c - k) % 26

        result += chr(p + ord('A'))
        key_index += 1

    return result


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(4096).decode()

            if not data:
                print("\nConnection closed by server.")
                break

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = vigenere_decrypt(data)

            print("\n" + "=" * 55)
            print("SERVER -> CLIENT")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("              VIGENERE CIPHER CLIENT")
print("=" * 55)

print()
print("Algorithm : Vigenère Cipher")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server.")

KEY = client.recv(1024).decode()

print("\nKey Information:")
print("Key       :", KEY)
print("C = (P + K) mod 26")
print("P = (C - K) mod 26")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(client,),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            client.send("exit".encode())
            print("Client ended the communication.")
            break

        ciphertext = vigenere_encrypt(message)

        print("\n" + "=" * 55)
        print("CLIENT -> SERVER")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to server...")
        print("=" * 55)

        client.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break


client.close()

print("\nClient closed.")