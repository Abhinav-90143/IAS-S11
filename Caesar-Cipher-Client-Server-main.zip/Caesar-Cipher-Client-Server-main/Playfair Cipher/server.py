import socket
import threading

HOST = "127.0.0.1"
PORT = 5002


def create_matrix(key):
    key = key.upper().replace("J", "I")

    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"
    letters = ""

    for char in key + alphabet:
        if char.isalpha() and char not in letters:
            letters += char

    matrix = [letters[i:i + 5] for i in range(0, 25, 5)]
    return matrix


def find_position(matrix, char):
    for row in range(5):
        for col in range(5):
            if matrix[row][col] == char:
                return row, col
    return None, None


def prepare_text(text):
    text = "".join(char.upper() for char in text if char.isalpha())
    text = text.replace("J", "I")

    result = ""
    i = 0

    while i < len(text):
        first = text[i]

        if i + 1 < len(text):
            second = text[i + 1]

            if first == second:
                result += first + "X"
                i += 1
            else:
                result += first + second
                i += 2
        else:
            result += first + "X"
            i += 1

    return result


def playfair_encrypt(text, matrix):
    text = prepare_text(text)
    result = ""

    for i in range(0, len(text), 2):
        a = text[i]
        b = text[i + 1]

        row1, col1 = find_position(matrix, a)
        row2, col2 = find_position(matrix, b)

        if row1 == row2:
            result += matrix[row1][(col1 + 1) % 5]
            result += matrix[row2][(col2 + 1) % 5]

        elif col1 == col2:
            result += matrix[(row1 + 1) % 5][col1]
            result += matrix[(row2 + 1) % 5][col2]

        else:
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


def playfair_decrypt(text, matrix):
    result = ""

    for i in range(0, len(text), 2):
        a = text[i]
        b = text[i + 1]

        row1, col1 = find_position(matrix, a)
        row2, col2 = find_position(matrix, b)

        if row1 == row2:
            result += matrix[row1][(col1 - 1) % 5]
            result += matrix[row2][(col2 - 1) % 5]

        elif col1 == col2:
            result += matrix[(row1 - 1) % 5][col1]
            result += matrix[(row2 - 1) % 5][col2]

        else:
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


def receive_messages(conn, matrix):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = playfair_decrypt(data, matrix)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("              PLAYFAIR CIPHER SERVER")
print("=" * 55)

print()
print("Algorithm : Playfair Cipher")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

key = input("\nEnter Playfair key: ")

matrix = create_matrix(key)

print("\nPlayfair Matrix:")

for row in matrix:
    print(" ".join(row))

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

# Send the key to the client
conn.send(key.encode())

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn, matrix),
    daemon=True
)

receive_thread.start()

while True:
    try:
        message = input("\nEnter server message: ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        ciphertext = playfair_encrypt(message, matrix)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break

conn.close()
server.close()

print("\nServer closed.")