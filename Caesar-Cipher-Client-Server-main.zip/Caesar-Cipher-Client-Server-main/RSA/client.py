import socket
import threading
import base64

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP


HOST = "127.0.0.1"
PORT = 5009


def send_data(sock, data):
    data_length = len(data).to_bytes(4, "big")
    sock.sendall(data_length + data)


def receive_data(sock):
    length_data = sock.recv(4)

    if not length_data:
        return b""

    data_length = int.from_bytes(length_data, "big")

    data = b""

    while len(data) < data_length:
        chunk = sock.recv(4096)

        if not chunk:
            break

        data += chunk

    return data


def rsa_encrypt(text, public_key):
    cipher = PKCS1_OAEP.new(public_key)
    encrypted = cipher.encrypt(text.encode())

    return base64.b64encode(encrypted).decode()


def rsa_decrypt(ciphertext, private_key):
    encrypted = base64.b64decode(ciphertext)

    cipher = PKCS1_OAEP.new(private_key)
    decrypted = cipher.decrypt(encrypted)

    return decrypted.decode()


def receive_messages(sock, private_key):
    while True:
        try:
            data = receive_data(sock)

            if not data:
                print("\nConnection closed by server.")
                break

            data = data.decode()

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = rsa_decrypt(data, private_key)

            print("\n" + "=" * 60)
            print("SERVER -> CLIENT")
            print("=" * 60)
            print("Encrypted ciphertext :", data)
            print("Decrypted plaintext  :", plaintext)
            print("=" * 60)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 60)
print("                    RSA CLIENT")
print("=" * 60)

print()
print("Algorithm : RSA (Rivest-Shamir-Adleman)")
print("Library   : PyCryptodome")
print("Host      :", HOST)
print("Port      :", PORT)
print("Key Size  : 2048 bits")
print("Padding   : PKCS1_OAEP")

print("\nGenerating RSA key pair...")

client_private_key = RSA.generate(2048)
client_public_key = client_private_key.publickey()

print("RSA key pair generated successfully.")

print("\nClient Key Information:")
print("Public Key  : Generated")
print("Private Key : Generated")
print("Modulus n   :", client_public_key.n)
print("Public e    :", client_public_key.e)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server.")


# Receive server public key
server_public_pem = receive_data(client)

server_public_key = RSA.import_key(server_public_pem)

# Send client public key
client_public_pem = client_public_key.export_key()
send_data(client, client_public_pem)

print("\nPublic Key Exchange:")
print("Server public key received.")
print("Client public key sent to server.")
print("Public key exchange completed successfully.")

print("\nServer Key Information:")
print("Public Key  : Received")
print("Modulus n   :", server_public_key.n)
print("Public e    :", server_public_key.e)

print("\nRSA Communication:")
print("Client encrypts using Server Public Key.")
print("Server decrypts using Server Private Key.")
print("Server encrypts using Client Public Key.")
print("Client decrypts using Client Private Key.")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")


receive_thread = threading.Thread(
    target=receive_messages,
    args=(client, client_private_key),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            send_data(client, b"exit")
            print("Client ended the communication.")
            break

        ciphertext = rsa_encrypt(message, server_public_key)

        print("\n" + "=" * 60)
        print("CLIENT -> SERVER")
        print("=" * 60)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Encrypting with server's public key...")
        print("=" * 60)

        send_data(client, ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break


client.close()

print("\nClient closed.")