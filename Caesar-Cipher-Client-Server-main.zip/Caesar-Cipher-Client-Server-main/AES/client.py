import socket
import threading
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

HOST = "127.0.0.1"
PORT = 5006

KEY = b"1234567890ABCDEF"


def aes_encrypt(text):
    cipher = AES.new(KEY, AES.MODE_ECB)
    encrypted = cipher.encrypt(pad(text.encode(), AES.block_size))
    return encrypted.hex()


def aes_decrypt(ciphertext):
    cipher = AES.new(KEY, AES.MODE_ECB)
    decrypted = cipher.decrypt(bytes.fromhex(ciphertext))
    return unpad(decrypted, AES.block_size).decode()


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(4096).decode()

            if not data:
                print("\nConnection closed by server.")
                break

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = aes_decrypt(data)

            print("\n" + "=" * 55)
            print("SERVER -> CLIENT")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                    AES CLIENT")
print("=" * 55)

print()
print("Algorithm : Advanced Encryption Standard (AES)")
print("Library   : PyCryptodome")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server.")

KEY = client.recv(1024)

print("\nKey Information:")
print("Key       :", KEY.decode())
print("Key Size  : 128 bits")
print("Block Size: 128 bits")
print("Mode      : ECB")

print("\nAES Transformations:")
print("SubBytes")
print("ShiftRows")
print("MixColumns")
print("AddRoundKey")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(client,),
    daemon=True
)

receive_thread.start()

while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            client.send("exit".encode())
            print("Client ended the communication.")
            break

        ciphertext = aes_encrypt(message)

        print("\n" + "=" * 55)
        print("CLIENT -> SERVER")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to server...")
        print("=" * 55)

        client.send(ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break

client.close()

print("\nClient closed.")