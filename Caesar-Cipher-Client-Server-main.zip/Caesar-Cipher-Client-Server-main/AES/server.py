import socket
import threading
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

HOST = "127.0.0.1"
PORT = 5006

KEY = b"1234567890ABCDEF"


def aes_encrypt(text):
    cipher = AES.new(KEY, AES.MODE_ECB)
    encrypted = cipher.encrypt(pad(text.encode(), AES.block_size))
    return encrypted.hex()


def aes_decrypt(ciphertext):
    cipher = AES.new(KEY, AES.MODE_ECB)
    decrypted = cipher.decrypt(bytes.fromhex(ciphertext))
    return unpad(decrypted, AES.block_size).decode()


def receive_messages(conn):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = aes_decrypt(data)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                    AES SERVER")
print("=" * 55)

print()
print("Algorithm : Advanced Encryption Standard (AES)")
print("Library   : PyCryptodome")
print("Host      :", HOST)
print("Port      :", PORT)
print("Key       :", KEY.decode())
print("Key Size  : 128 bits")
print("Block Size: 128 bits")
print("Mode      : ECB")

print("\nAES Transformations:")
print("SubBytes")
print("ShiftRows")
print("MixColumns")
print("AddRoundKey")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

conn.send(KEY)

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn,),
    daemon=True
)

receive_thread.start()

while True:
    try:
        message = input("\nEnter server message: ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        ciphertext = aes_encrypt(message)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break

conn.close()
server.close()

print("\nServer closed.")