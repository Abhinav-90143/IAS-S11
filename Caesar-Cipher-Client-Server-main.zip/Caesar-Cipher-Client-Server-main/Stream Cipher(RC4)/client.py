import socket
import threading
from Crypto.Cipher import ARC4

HOST = "127.0.0.1"
PORT = 5007

KEY = b"SECRETKEY"


def rc4_encrypt(text):
    cipher = ARC4.new(KEY)
    encrypted = cipher.encrypt(text.encode())
    return encrypted.hex()


def rc4_decrypt(ciphertext):
    cipher = ARC4.new(KEY)
    decrypted = cipher.decrypt(bytes.fromhex(ciphertext))
    return decrypted.decode()


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(4096).decode()

            if not data:
                print("\nConnection closed by server.")
                break

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = rc4_decrypt(data)

            print("\n" + "=" * 55)
            print("SERVER -> CLIENT")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except Exception:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                    RC4 CLIENT")
print("=" * 55)

print()
print("Algorithm : RC4 Stream Cipher")
print("Library   : PyCryptodome")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server.")

KEY = client.recv(1024)

print("\nKey Information:")
print("Key       :", KEY.decode())
print("Key Size  :", len(KEY) * 8, "bits")

print("\nRC4 Operations:")
print("C = P XOR K")
print("P = C XOR K")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(client,),
    daemon=True
)

receive_thread.start()


while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            client.send("exit".encode())
            print("Client ended the communication.")
            break

        ciphertext = rc4_encrypt(message)

        print("\n" + "=" * 55)
        print("CLIENT -> SERVER")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to server...")
        print("=" * 55)

        client.send(ciphertext.encode())

    except Exception:
        print("\nConnection closed.")
        break


client.close()

print("\nClient closed.")