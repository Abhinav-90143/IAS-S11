import socket
import threading

HOST = "127.0.0.1"
PORT = 5003


def hill_encrypt(text):
    key_matrix = [
        [3, 3],
        [2, 5]
    ]

    text = "".join(char.upper() for char in text if char.isalpha())

    if len(text) % 2 != 0:
        text += "X"

    result = ""

    for i in range(0, len(text), 2):
        x1 = ord(text[i]) - ord('A')
        x2 = ord(text[i + 1]) - ord('A')

        y1 = (key_matrix[0][0] * x1 +
              key_matrix[0][1] * x2) % 26

        y2 = (key_matrix[1][0] * x1 +
              key_matrix[1][1] * x2) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


def hill_decrypt(text):
    inverse_matrix = [
        [15, 17],
        [20, 9]
    ]

    result = ""

    for i in range(0, len(text), 2):
        x1 = ord(text[i]) - ord('A')
        x2 = ord(text[i + 1]) - ord('A')

        y1 = (inverse_matrix[0][0] * x1 +
              inverse_matrix[0][1] * x2) % 26

        y2 = (inverse_matrix[1][0] * x1 +
              inverse_matrix[1][1] * x2) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


def receive_messages(sock):
    while True:
        try:
            data = sock.recv(4096).decode()

            if not data:
                print("\nConnection closed by server.")
                break

            if data == "exit":
                print("\nServer ended the communication.")
                break

            plaintext = hill_decrypt(data)

            print("\n" + "=" * 55)
            print("SERVER -> CLIENT")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                HILL CIPHER CLIENT")
print("=" * 55)

print()
print("Algorithm : Hill Cipher")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nConnecting to server...")

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((HOST, PORT))

print("Connected to server.")

# Receive key matrix from server
key_data = client.recv(1024).decode()

print("\nKey Matrix:")
print("[3 3]")
print("[2 5]")

print("\nKey Information:")
print("K = [[3, 3], [2, 5]]")
print("All calculations are performed modulo 26.")

print("\nClient is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(client,),
    daemon=True
)

receive_thread.start()

while True:
    try:
        message = input("\nEnter client message: ")

        if message.lower() == "exit":
            client.send("exit".encode())
            print("Client ended the communication.")
            break

        ciphertext = hill_encrypt(message)

        print("\n" + "=" * 55)
        print("CLIENT -> SERVER")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to server...")
        print("=" * 55)

        client.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break

client.close()

print("\nClient closed.")