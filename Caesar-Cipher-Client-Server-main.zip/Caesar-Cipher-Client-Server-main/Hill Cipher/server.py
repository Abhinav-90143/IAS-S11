import socket
import threading

HOST = "127.0.0.1"
PORT = 5003

KEY_MATRIX = [
    [3, 3],
    [2, 5]
]


def hill_encrypt(text):
    text = "".join(char.upper() for char in text if char.isalpha())

    if len(text) % 2 != 0:
        text += "X"

    result = ""

    for i in range(0, len(text), 2):
        x1 = ord(text[i]) - ord('A')
        x2 = ord(text[i + 1]) - ord('A')

        y1 = (KEY_MATRIX[0][0] * x1 +
              KEY_MATRIX[0][1] * x2) % 26

        y2 = (KEY_MATRIX[1][0] * x1 +
              KEY_MATRIX[1][1] * x2) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


def hill_decrypt(text):
    # Inverse of the key matrix modulo 26
    # det = (3*5) - (3*2) = 9
    # inverse of 9 modulo 26 = 3

    inverse_matrix = [
        [15, 17],
        [20, 9]
    ]

    result = ""

    for i in range(0, len(text), 2):
        x1 = ord(text[i]) - ord('A')
        x2 = ord(text[i + 1]) - ord('A')

        y1 = (inverse_matrix[0][0] * x1 +
              inverse_matrix[0][1] * x2) % 26

        y2 = (inverse_matrix[1][0] * x1 +
              inverse_matrix[1][1] * x2) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


def receive_messages(conn):
    while True:
        try:
            data = conn.recv(4096).decode()

            if not data:
                print("\nConnection closed by client.")
                break

            if data == "exit":
                print("\nClient ended the communication.")
                break

            plaintext = hill_decrypt(data)

            print("\n" + "=" * 55)
            print("CLIENT -> SERVER")
            print("=" * 55)
            print("Ciphertext         :", data)
            print("Decrypted plaintext:", plaintext)
            print("=" * 55)

        except:
            print("\nConnection closed.")
            break


print("=" * 55)
print("                HILL CIPHER SERVER")
print("=" * 55)

print()
print("Algorithm : Hill Cipher")
print("Library   : Python Standard Library")
print("Host      :", HOST)
print("Port      :", PORT)

print("\nKey Matrix:")
for row in KEY_MATRIX:
    print(row)

print("\nKey Information:")
print("K = [[3, 3], [2, 5]]")
print("All calculations are performed modulo 26.")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server.bind((HOST, PORT))
server.listen(1)

print("\nWaiting for client connection...")

conn, address = server.accept()

print("Connected to :", address)

# Send key matrix to client
key_data = "3,3,2,5"
conn.send(key_data.encode())

print("\nServer is ready.")
print("Two-way communication started.")
print("Type 'exit' to stop.")

receive_thread = threading.Thread(
    target=receive_messages,
    args=(conn,),
    daemon=True
)

receive_thread.start()

while True:
    try:
        message = input("\nEnter server message: ")

        if message.lower() == "exit":
            conn.send("exit".encode())
            print("Server ended the communication.")
            break

        ciphertext = hill_encrypt(message)

        print("\n" + "=" * 55)
        print("SERVER -> CLIENT")
        print("=" * 55)
        print("Plaintext :", message)
        print("Ciphertext:", ciphertext)
        print("Sending ciphertext to client...")
        print("=" * 55)

        conn.send(ciphertext.encode())

    except:
        print("\nConnection closed.")
        break

conn.close()
server.close()

print("\nServer closed.")